/***********************************************************************
 * Module:  TravelAgencySellSystem.cpp
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 16:29:23
 * Purpose: Implementation of the class TravelAgencySellSystem
 ***********************************************************************/

#include "TravelAgencySellSystem.h"

////////////////////////////////////////////////////////////////////////
// Name:       TravelAgencySellSystem::sellTicket(Flight flight)
// Purpose:    Implementation of TravelAgencySellSystem::sellTicket()
// Parameters:
// - flight
// Return:     Ticket
////////////////////////////////////////////////////////////////////////

Ticket TravelAgencySellSystem::sellTicket(Flight flight)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       TravelAgencySellSystem::getFlightsBetweenCities(eCity departure, eCity arrival)
// Purpose:    Implementation of TravelAgencySellSystem::getFlightsBetweenCities()
// Parameters:
// - departure
// - arrival
// Return:     list
////////////////////////////////////////////////////////////////////////

list TravelAgencySellSystem::getFlightsBetweenCities(eCity departure, eCity arrival)
{
   // TODO : implement
}