/***********************************************************************
 * Module:  TradingPostSellSystem.cpp
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 16:29:32
 * Purpose: Implementation of the class TradingPostSellSystem
 ***********************************************************************/

#include "TradingPostSellSystem.h"

////////////////////////////////////////////////////////////////////////
// Name:       TradingPostSellSystem::sellTicket(Flight flight)
// Purpose:    Implementation of TradingPostSellSystem::sellTicket()
// Parameters:
// - flight
// Return:     Ticket
////////////////////////////////////////////////////////////////////////

Ticket TradingPostSellSystem::sellTicket(Flight flight)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       TradingPostSellSystem::getFlightsBetweenCities(eCity departure, eCity arrival)
// Purpose:    Implementation of TradingPostSellSystem::getFlightsBetweenCities()
// Parameters:
// - departure
// - arrival
// Return:     list
////////////////////////////////////////////////////////////////////////

list TradingPostSellSystem::getFlightsBetweenCities(eCity departure, eCity arrival)
{
   // TODO : implement
}