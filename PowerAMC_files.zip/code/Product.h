/***********************************************************************
 * Module:  Product.h
 * Author:  Alexis
 * Modified: jeudi 7 novembre 2013 15:56:37
 * Purpose: Declaration of the class Product
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_Product_h)
#define __ClassDiagramReset2_Product_h

class eProduct;

class Product
{
public:
   eProduct* eProduct;

protected:
private:

};

#endif