/***********************************************************************
 * Module:  eCity.h
 * Author:  Alexis
 * Modified: jeudi 7 novembre 2013 16:59:46
 * Purpose: Declaration of the class eCity
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_eCity_h)
#define __ClassDiagramReset2_eCity_h

class eCity
{
public:
   Object Paris;
   Object Nice;
   Object Toulouse;
   Object Marseille;

protected:
private:

};

#endif