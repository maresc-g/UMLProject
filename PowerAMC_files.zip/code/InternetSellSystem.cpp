/***********************************************************************
 * Module:  InternetSellSystem.cpp
 * Author:  Alexis
 * Modified: dimanche 10 novembre 2013 17:45:58
 * Purpose: Implementation of the class InternetSellSystem
 ***********************************************************************/

#include "InternetSellSystem.h"

////////////////////////////////////////////////////////////////////////
// Name:       InternetSellSystem::sellTicket(Flight flight)
// Purpose:    Implementation of InternetSellSystem::sellTicket()
// Parameters:
// - flight
// Return:     Ticket
////////////////////////////////////////////////////////////////////////

Ticket InternetSellSystem::sellTicket(Flight flight)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       InternetSellSystem::getFlightsBetweenCities(eCity departure, eCity arrival)
// Purpose:    Implementation of InternetSellSystem::getFlightsBetweenCities()
// Parameters:
// - departure
// - arrival
// Return:     list
////////////////////////////////////////////////////////////////////////

list InternetSellSystem::getFlightsBetweenCities(eCity departure, eCity arrival)
{
   // TODO : implement
}