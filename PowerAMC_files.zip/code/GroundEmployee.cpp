/***********************************************************************
 * Module:  GroundEmployee.cpp
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 15:22:47
 * Purpose: Implementation of the class GroundEmployee
 ***********************************************************************/

#include "GroundEmployee.h"

////////////////////////////////////////////////////////////////////////
// Name:       GroundEmployee::register(Ticket ticket)
// Purpose:    Implementation of GroundEmployee::register()
// Parameters:
// - ticket
// Return:     bool
////////////////////////////////////////////////////////////////////////

bool GroundEmployee::register(Ticket ticket)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       GroundEmployee::registerLuggage()
// Purpose:    Implementation of GroundEmployee::registerLuggage()
// Return:     bool
////////////////////////////////////////////////////////////////////////

bool GroundEmployee::registerLuggage(void)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       GroundEmployee::checkLuggage()
// Purpose:    Implementation of GroundEmployee::checkLuggage()
// Return:     bool
////////////////////////////////////////////////////////////////////////

bool GroundEmployee::checkLuggage(void)
{
   // TODO : implement
}