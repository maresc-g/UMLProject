/***********************************************************************
 * Module:  Emailer.cpp
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 12:39:09
 * Purpose: Implementation of the class Emailer
 ***********************************************************************/

#include "Emailer.h"

////////////////////////////////////////////////////////////////////////
// Name:       Emailer::send(Email mail)
// Purpose:    Implementation of Emailer::send()
// Parameters:
// - mail
// Return:     void
////////////////////////////////////////////////////////////////////////

void Emailer::send(Email mail)
{
   // TODO : implement
}