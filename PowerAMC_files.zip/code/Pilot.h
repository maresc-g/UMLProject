/***********************************************************************
 * Module:  Pilot.h
 * Author:  Alexis
 * Modified: dimanche 10 novembre 2013 17:45:58
 * Purpose: Declaration of the class Pilot
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_Pilot_h)
#define __ClassDiagramReset2_Pilot_h

#include <FlyingEmployee.h>

class Pilot : public FlyingEmployee
{
public:
protected:
private:

};

#endif