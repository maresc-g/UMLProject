/***********************************************************************
 * Module:  Emailer.h
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 12:39:09
 * Purpose: Declaration of the class Emailer
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_Emailer_h)
#define __ClassDiagramReset2_Emailer_h

#include <Email.h>

class Emailer
{
public:
   void send(Email mail);

protected:
private:

};

#endif