/***********************************************************************
 * Module:  FreeDay.h
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 13:55:45
 * Purpose: Declaration of the class FreeDay
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_FreeDay_h)
#define __ClassDiagramReset2_FreeDay_h

#include <AEvent.h>

class FreeDay : public AEvent
{
public:
protected:
private:

};

#endif