/***********************************************************************
 * Module:  eProduct.h
 * Author:  Alexis
 * Modified: jeudi 7 novembre 2013 15:56:37
 * Purpose: Declaration of the class eProduct
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_eProduct_h)
#define __ClassDiagramReset2_eProduct_h

class eProduct
{
public:
   int Drink;
   int Food;
   int NewsPaper;

protected:
private:

};

#endif