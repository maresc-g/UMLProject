/***********************************************************************
 * Module:  Steward.cpp
 * Author:  Alexis
 * Modified: dimanche 10 novembre 2013 17:46:32
 * Purpose: Implementation of the class Steward
 ***********************************************************************/

#include "Steward.h"

////////////////////////////////////////////////////////////////////////
// Name:       Steward::checkBoardingCard(Ticket ticket)
// Purpose:    Implementation of Steward::checkBoardingCard()
// Parameters:
// - ticket
// Return:     bool
////////////////////////////////////////////////////////////////////////

bool Steward::checkBoardingCard(Ticket ticket)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       Steward::sellProduct(int price, eProduct type)
// Purpose:    Implementation of Steward::sellProduct()
// Parameters:
// - price
// - type
// Return:     Product
////////////////////////////////////////////////////////////////////////

Product Steward::sellProduct(int price, eProduct type)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       Steward::getProductPrice(eProduct type)
// Purpose:    Implementation of Steward::getProductPrice()
// Parameters:
// - type
// Return:     int
////////////////////////////////////////////////////////////////////////

int Steward::getProductPrice(eProduct type)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       Steward::checkIfEveryoneIsOnBoard()
// Purpose:    Implementation of Steward::checkIfEveryoneIsOnBoard()
// Return:     bool
////////////////////////////////////////////////////////////////////////

bool Steward::checkIfEveryoneIsOnBoard(void)
{
   // TODO : implement
}