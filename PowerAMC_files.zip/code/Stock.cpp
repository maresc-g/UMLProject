/***********************************************************************
 * Module:  Stock.cpp
 * Author:  Alexis
 * Modified: jeudi 7 novembre 2013 15:55:23
 * Purpose: Implementation of the class Stock
 ***********************************************************************/

#include "Product.h"
#include "Stock.h"

////////////////////////////////////////////////////////////////////////
// Name:       Stock::getProduct(eProduct type)
// Purpose:    Implementation of Stock::getProduct()
// Parameters:
// - type
// Return:     Product
////////////////////////////////////////////////////////////////////////

Product Stock::getProduct(eProduct type)
{
   // TODO : implement
}