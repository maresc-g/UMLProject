/***********************************************************************
 * Module:  eEvent.h
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 13:56:10
 * Purpose: Declaration of the class eEvent
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_eEvent_h)
#define __ClassDiagramReset2_eEvent_h

class eEvent
{
public:
   Object Flight;
   Object Checking;
   Object Refuel;
   Object StockRenewal;
   Object Cleaning;
   Object FreeDay;

protected:
private:

};

#endif