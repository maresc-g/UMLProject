/***********************************************************************
 * Module:  eEmployee.h
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 14:24:49
 * Purpose: Declaration of the class eEmployee
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_eEmployee_h)
#define __ClassDiagramReset2_eEmployee_h

class eEmployee
{
public:
   Object Pilot;
   Object Steward;
   Object GroundEmployee;

protected:
private:

};

#endif