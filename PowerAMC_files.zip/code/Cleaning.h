/***********************************************************************
 * Module:  Cleaning.h
 * Author:  Alexis
 * Modified: jeudi 7 novembre 2013 16:00:47
 * Purpose: Declaration of the class Cleaning
 ***********************************************************************/

#if !defined(__ClassDiagramReset2_Cleaning_h)
#define __ClassDiagramReset2_Cleaning_h

#include <AEvent.h>

class Cleaning : public AEvent
{
public:
protected:
private:

};

#endif