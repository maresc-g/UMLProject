/***********************************************************************
 * Module:  Checking.cpp
 * Author:  Alexis
 * Modified: dimanche 10 novembre 2013 17:46:14
 * Purpose: Implementation of the class Checking
 ***********************************************************************/

#include "CheckingReport.h"
#include "Checking.h"

////////////////////////////////////////////////////////////////////////
// Name:       Checking::getCheckingReport()
// Purpose:    Implementation of Checking::getCheckingReport()
// Return:     CheckingReport
////////////////////////////////////////////////////////////////////////

CheckingReport Checking::getCheckingReport(void)
{
   // TODO : implement
}