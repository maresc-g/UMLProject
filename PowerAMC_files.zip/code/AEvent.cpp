/***********************************************************************
 * Module:  AEvent.cpp
 * Author:  Alexis
 * Modified: vendredi 8 novembre 2013 13:25:49
 * Purpose: Implementation of the class AEvent
 ***********************************************************************/

#include "Invoice.h"
#include "eEvent.h"
#include "Date.h"
#include "AEvent.h"

////////////////////////////////////////////////////////////////////////
// Name:       AEvent::getType()
// Purpose:    Implementation of AEvent::getType()
// Return:     eEvent
////////////////////////////////////////////////////////////////////////

eEvent AEvent::getType(void)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       AEvent::getDates()
// Purpose:    Implementation of AEvent::getDates()
// Return:     list
////////////////////////////////////////////////////////////////////////

list AEvent::getDates(void)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       AEvent::setDates(list _dates)
// Purpose:    Implementation of AEvent::setDates()
// Parameters:
// - _dates
// Return:     void
////////////////////////////////////////////////////////////////////////

void AEvent::setDates(list _dates)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       AEvent::getInvoice()
// Purpose:    Implementation of AEvent::getInvoice()
// Return:     Invoice
////////////////////////////////////////////////////////////////////////

Invoice AEvent::getInvoice(void)
{
   // TODO : implement
}